import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

const plans = [
  {
    name: "Starter",
    price: "$29",
    description: "Perfect for small teams getting started",
    features: ["Up to 5 team members", "Basic analytics", "24/7 support", "1GB storage"],
  },
  {
    name: "Professional",
    price: "$99",
    description: "For growing teams that need more",
    features: [
      "Up to 20 team members",
      "Advanced analytics",
      "Priority support",
      "10GB storage",
      "Custom integrations",
    ],
    popular: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "For large organizations with custom needs",
    features: [
      "Unlimited team members",
      "Enterprise analytics",
      "Dedicated support",
      "Unlimited storage",
      "Custom integrations",
      "SLA guarantee",
    ],
  },
]

export default function PricingTable() {
  return (
    <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
      {plans.map((plan, index) => (
        <div
          key={index}
          className={`bg-white rounded-lg shadow-sm border p-8 relative ${
            plan.popular ? "border-primary shadow-lg" : ""
          }`}
        >
          {plan.popular && (
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <span className="bg-primary text-primary-foreground text-sm font-medium px-3 py-1 rounded-full">
                Most Popular
              </span>
            </div>
          )}
          <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
          <div className="mb-4">
            <span className="text-3xl font-bold">{plan.price}</span>
            {plan.price !== "Custom" && <span className="text-muted-foreground">/month</span>}
          </div>
          <p className="text-muted-foreground mb-6">{plan.description}</p>
          <Button className="w-full mb-6" variant={plan.popular ? "default" : "outline"}>
            Get Started
          </Button>
          <ul className="space-y-3">
            {plan.features.map((feature, featureIndex) => (
              <li key={featureIndex} className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  )
}

