"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { History, X, Plus, Minus, Divide, Equal, Percent } from "lucide-react"
import { cn } from "@/lib/utils"

type CalculatorHistory = {
  calculation: string
  result: string
  timestamp: Date
}

export default function Calculator() {
  const [display, setDisplay] = useState("0")
  const [previousNumber, setPreviousNumber] = useState("")
  const [operation, setOperation] = useState("")
  const [shouldResetDisplay, setShouldResetDisplay] = useState(false)
  const [history, setHistory] = useState<CalculatorHistory[]>([])
  const [showHistory, setShowHistory] = useState(false)

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= "0" && e.key <= "9") {
        handleNumber(e.key)
      } else if (e.key === ".") {
        handleDecimal()
      } else if (e.key === "+") {
        handleOperation("+")
      } else if (e.key === "-") {
        handleOperation("-")
      } else if (e.key === "*") {
        handleOperation("×")
      } else if (e.key === "/") {
        handleOperation("÷")
      } else if (e.key === "Enter" || e.key === "=") {
        handleEqual()
      } else if (e.key === "Escape") {
        handleClear()
      } else if (e.key === "Backspace") {
        handleDelete()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  const handleNumber = (num: string) => {
    if (shouldResetDisplay) {
      setDisplay(num)
      setShouldResetDisplay(false)
    } else {
      setDisplay(display === "0" ? num : display + num)
    }
  }

  const handleDecimal = () => {
    if (shouldResetDisplay) {
      setDisplay("0.")
      setShouldResetDisplay(false)
    } else if (!display.includes(".")) {
      setDisplay(display + ".")
    }
  }

  const handleOperation = (op: string) => {
    if (operation && previousNumber) {
      handleEqual()
    }
    setPreviousNumber(display)
    setOperation(op)
    setShouldResetDisplay(true)
  }

  const handleEqual = () => {
    if (!operation || !previousNumber) return

    const prev = Number.parseFloat(previousNumber)
    const current = Number.parseFloat(display)
    let result = 0

    switch (operation) {
      case "+":
        result = prev + current
        break
      case "-":
        result = prev - current
        break
      case "×":
        result = prev * current
        break
      case "÷":
        if (current === 0) {
          setDisplay("Error")
          setPreviousNumber("")
          setOperation("")
          setShouldResetDisplay(true)
          return
        }
        result = prev / current
        break
      case "%":
        result = (prev * current) / 100
        break
    }

    const formattedResult = formatNumber(result)
    const calculation = `${previousNumber} ${operation} ${display}`

    setHistory((prev) =>
      [
        {
          calculation,
          result: formattedResult,
          timestamp: new Date(),
        },
        ...prev,
      ].slice(0, 10),
    )

    setDisplay(formattedResult)
    setPreviousNumber("")
    setOperation("")
    setShouldResetDisplay(true)
  }

  const formatNumber = (num: number): string => {
    return Number.isInteger(num) ? num.toString() : num.toFixed(8).replace(/\.?0+$/, "")
  }

  const handleClear = () => {
    setDisplay("0")
    setPreviousNumber("")
    setOperation("")
    setShouldResetDisplay(false)
  }

  const handleDelete = () => {
    if (display.length === 1 || display === "Error") {
      setDisplay("0")
    } else {
      setDisplay(display.slice(0, -1))
    }
  }

  const handlePercent = () => {
    const num = Number.parseFloat(display)
    setDisplay((num / 100).toString())
  }

  return (
    <div className="relative">
      {/* Calculator */}
      <div className="w-full max-w-md bg-slate-800 rounded-3xl shadow-xl overflow-hidden">
        {/* Display */}
        <div className="p-6 pb-0">
          <div className="flex justify-between items-center mb-2">
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="text-slate-400 hover:text-white transition-colors"
            >
              <History className="h-5 w-5" />
            </button>
            {previousNumber && (
              <div className="text-slate-400 text-right">
                {previousNumber} {operation}
              </div>
            )}
          </div>
          <div className="h-20 flex items-center justify-end">
            <div className="text-4xl font-light text-white tracking-wider">{display}</div>
          </div>
        </div>

        {/* Buttons Grid */}
        <div className="grid grid-cols-4 gap-2 p-6">
          {/* First Row */}
          <Button
            variant="ghost"
            className="h-14 text-red-500 hover:text-red-400 hover:bg-slate-700/50"
            onClick={handleClear}
          >
            AC
          </Button>
          <Button
            variant="ghost"
            className="h-14 text-slate-400 hover:text-white hover:bg-slate-700/50"
            onClick={handleDelete}
          >
            <X className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            className="h-14 text-slate-400 hover:text-white hover:bg-slate-700/50"
            onClick={handlePercent}
          >
            <Percent className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            className="h-14 text-slate-400 hover:text-white hover:bg-slate-700/50"
            onClick={() => handleOperation("÷")}
          >
            <Divide className="h-5 w-5" />
          </Button>

          {/* Number Pad */}
          {[7, 8, 9, 4, 5, 6, 1, 2, 3].map((num) => (
            <Button
              key={num}
              variant="ghost"
              className="h-14 text-white text-2xl hover:bg-slate-700/50"
              onClick={() => handleNumber(num.toString())}
            >
              {num}
            </Button>
          ))}

          {/* Operators */}
          <Button
            variant="ghost"
            className="h-14 text-slate-400 hover:text-white hover:bg-slate-700/50"
            onClick={() => handleOperation("×")}
          >
            ×
          </Button>
          <Button
            variant="ghost"
            className="h-14 text-slate-400 hover:text-white hover:bg-slate-700/50"
            onClick={() => handleOperation("-")}
          >
            <Minus className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            className="h-14 text-slate-400 hover:text-white hover:bg-slate-700/50"
            onClick={() => handleOperation("+")}
          >
            <Plus className="h-5 w-5" />
          </Button>

          {/* Last Row */}
          <Button
            variant="ghost"
            className="h-14 text-white text-2xl hover:bg-slate-700/50"
            onClick={() => handleNumber("0")}
          >
            0
          </Button>
          <Button variant="ghost" className="h-14 text-white text-2xl hover:bg-slate-700/50" onClick={handleDecimal}>
            .
          </Button>
          <Button
            variant="ghost"
            className="h-14 col-span-2 bg-blue-500 hover:bg-blue-600 text-white"
            onClick={handleEqual}
          >
            <Equal className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* History Panel */}
      <div
        className={cn(
          "absolute top-0 right-0 h-full w-64 bg-slate-800 shadow-xl transform transition-transform duration-300 ease-in-out",
          showHistory ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="p-4">
          <h3 className="text-white font-medium mb-4">History</h3>
          <div className="space-y-3">
            {history.map((item, index) => (
              <div key={index} className="text-sm">
                <div className="text-slate-400">{item.calculation}</div>
                <div className="text-white font-medium">{item.result}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

