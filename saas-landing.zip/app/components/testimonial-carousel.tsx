"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"

const testimonials = [
  {
    quote: "StreamLine has completely transformed how our team works. The productivity gains have been incredible.",
    author: "Sarah Johnson",
    role: "CEO at TechCorp",
    image: "/placeholder.svg?height=64&width=64",
  },
  {
    quote:
      "The best workflow management tool we've ever used. It's intuitive, powerful, and saves us hours every week.",
    author: "Michael Chen",
    role: "Product Manager at InnovateCo",
    image: "/placeholder.svg?height=64&width=64",
  },
  {
    quote: "Implementation was smooth, and the ROI was immediate. Our team loves using StreamLine.",
    author: "Emily Rodriguez",
    role: "Director of Operations at GrowthInc",
    image: "/placeholder.svg?height=64&width=64",
  },
]

export default function TestimonialCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const next = () => {
    setCurrentIndex((currentIndex + 1) % testimonials.length)
  }

  const previous = () => {
    setCurrentIndex((currentIndex - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <div className="relative max-w-3xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm border p-8 md:p-12">
        <Quote className="h-12 w-12 text-primary/20 mb-6" />
        <blockquote className="text-xl md:text-2xl mb-8">{testimonials[currentIndex].quote}</blockquote>
        <div className="flex items-center gap-4">
          <img
            src={testimonials[currentIndex].image || "/placeholder.svg"}
            alt={testimonials[currentIndex].author}
            className="rounded-full w-16 h-16"
          />
          <div>
            <div className="font-semibold">{testimonials[currentIndex].author}</div>
            <div className="text-muted-foreground">{testimonials[currentIndex].role}</div>
          </div>
        </div>
      </div>
      <div className="flex justify-center gap-2 mt-6">
        <Button variant="outline" size="icon" onClick={previous} aria-label="Previous testimonial">
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={next} aria-label="Next testimonial">
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

